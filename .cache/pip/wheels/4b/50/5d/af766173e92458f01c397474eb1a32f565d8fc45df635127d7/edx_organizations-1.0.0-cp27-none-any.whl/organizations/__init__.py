"""
edx-organizations app initialization module
"""
__version__ = '1.0.0'  # pragma: no cover
