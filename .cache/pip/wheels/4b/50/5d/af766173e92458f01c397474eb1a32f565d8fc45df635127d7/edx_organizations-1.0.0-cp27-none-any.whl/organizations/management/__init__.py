"""
edx-organizations management package initialization module
"""
