"""
edx-organizations management commands tests package initialization module
"""
