from django.db import models

class CourseChatbot(models.Model):
    chatbot_name = models.CharField(max_length=100, blank=True, verbose_name='Chatbot Name')
    course_id = models.CharField(max_length=100, blank=True, verbose_name='Course ID')
    chatbot_url = models.CharField(max_length=300, blank=True, verbose_name='Chatbot URL')
    
    def __str__(self):
        return self.chatbot_name

    class Meta:
        app_label = "edxchatbot"
        verbose_name = ('Edx Chatbot')
        verbose_name_plural = ('Edx Chatbots')
