from django import template
from edxchatbot.models import CourseChatbot

register = template.Library()

@register.filter
def get_chatbot_url(course_id):
     """
     Get chatbot url for the course

     """
     course_chatbot = CourseChatbot.objects.get(course_id=course_id)
     return course_chatbot.chatbot_url
