# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Twisted Enterprise: Database support for Twisted services.
"""

__all__ = ['adbapi']
