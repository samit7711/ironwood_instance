"""News Tests"""
