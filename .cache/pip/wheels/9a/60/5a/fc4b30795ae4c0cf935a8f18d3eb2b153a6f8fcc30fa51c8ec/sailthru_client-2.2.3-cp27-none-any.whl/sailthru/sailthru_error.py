# -*- coding: utf-8 -*-

class SailthruClientError(Exception):
    pass
