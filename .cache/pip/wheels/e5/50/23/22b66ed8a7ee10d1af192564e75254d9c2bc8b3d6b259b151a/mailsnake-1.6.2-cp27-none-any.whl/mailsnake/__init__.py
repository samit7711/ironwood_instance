from .mailsnake import *

__author__ = 'John-Kim Murphy'
__credits__ = [
    'John-Kim Murphy',
    'Michael Helmick',
    'Brad Pitcher',
    'vlinhart',
    'starenka',
    'Ryan Tucker'
]
__version__ = '1.6.1'

__all__ = ['MailSnake']
