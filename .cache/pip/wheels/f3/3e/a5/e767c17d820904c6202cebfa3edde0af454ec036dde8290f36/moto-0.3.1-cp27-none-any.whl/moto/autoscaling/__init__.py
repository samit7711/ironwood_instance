from .models import autoscaling_backend
mock_autoscaling = autoscaling_backend.decorator
