from .models import dynamodb_backend2
mock_dynamodb2 = dynamodb_backend2.decorator
