from .models import ec2_backend
mock_ec2 = ec2_backend.decorator
