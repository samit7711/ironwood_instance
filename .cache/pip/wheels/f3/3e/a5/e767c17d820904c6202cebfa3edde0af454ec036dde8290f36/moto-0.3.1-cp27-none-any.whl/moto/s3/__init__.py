from .models import s3_backend
mock_s3 = s3_backend.decorator
