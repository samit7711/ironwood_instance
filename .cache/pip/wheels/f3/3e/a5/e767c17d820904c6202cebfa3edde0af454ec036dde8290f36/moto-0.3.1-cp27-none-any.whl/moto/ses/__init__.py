from .models import ses_backend
mock_ses = ses_backend.decorator
