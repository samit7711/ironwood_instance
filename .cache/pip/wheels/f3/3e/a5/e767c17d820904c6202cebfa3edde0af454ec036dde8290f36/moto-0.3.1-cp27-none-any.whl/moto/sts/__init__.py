from .models import sts_backend
mock_sts = sts_backend.decorator
